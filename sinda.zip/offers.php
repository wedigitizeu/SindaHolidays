<div class="widget widget-testimonial">
              <h4 class="widget-title">Offers</h4>
              <div class="widget-body">
                <div class="testimonial-slider owl-carousel">
                  <div class="testimonial-item">
                    <div class="testimonial-item--header">
                      <div class="thumb">
                        <!--<img src="assets/images/testimonial/1.jpg" alt="image">-->
                      </div>
                      <div class="content">
                      <!--  <h6 class="name">martin hook</h6>
                        <span class="designation"><?php echo title_name();?></span>--->
                      </div>
                    </div>
                    <div class="testimonial-item--body">
                      <p>No offers Yet</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>