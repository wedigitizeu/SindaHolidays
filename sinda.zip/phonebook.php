<?php

function title_name()
{
	return "Sinda Tours and Travels";
}
function name()

{
	return "Sinda Tours and Travels";
}
function address()
{
	return "SINDA TOURS & TRAVELS
		28, 12th Main, Subbaiah Hospital Road,
		Mathikere,Bangalore - 560054.";
}
function address1()
{
	return "Mathikere";
}
function title()
{
	return "Sinda Tours and Travels";
}
function gmail()
{
	return "sindaholidays@gmail.com";
}

function timings()
{
	return "Mon - Sat  9:00 am - 8.30 pm";
}

function mobile()
{
	return "9902169997";
}

function facebook()
{
	return "#";
}

function twitter()
{
	return "#";
}
?>