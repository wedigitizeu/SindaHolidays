<div class="scroll-to-top">
    <span class="scroll-icon">
      <i class="fa fa-arrow-up"></i>
    </span>

    
  </div>